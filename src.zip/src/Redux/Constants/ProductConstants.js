export const GET_PRODUCT_SUCCESS = "getProductSuccess";

export const GET_PRODUCT_FAIL = "getProductFail";

export const GET_PRODUCT_DETAILS_REQUEST = "getProductDetailsRequest";

export const GET_PRODUCT_DETAILS_SUCCESS = "getProductDetailsSuccess";

export const GET_PRODUCT_DETAILS_FAIL = "getProductDetailFailed";

export const GET_PRODUCT_DETAILS_RESET = "ProductDetailsReset";
