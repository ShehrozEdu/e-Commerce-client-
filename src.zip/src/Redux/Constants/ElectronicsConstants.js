export const GET_ELECTRONICS_SUCCESS = "getElectronicsSuccess";

export const GET_ELECTRONICS_FAIL = "getElectronicsFail";

export const GET_ELECTRONICS_DETAILS_REQUEST = "getElectronicsDetailsRequest";

export const GET_ELECTRONICS_DETAILS_SUCCESS = "getElectronicsDetailsSuccess";

export const GET_ELECTRONICS_DETAILS_FAIL = "getElectronicsDetailFailed";

export const GET_ELECTRONICS_DETAILS_RESET = "ElectronicsDetailsReset";
