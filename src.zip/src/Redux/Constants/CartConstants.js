export const ADD_TO_CART = "addToCart";
export const ADD_TO_CART_ERROR = "addToCartError";
export const REMOVE_FROM_CART = "removeFromCart";
