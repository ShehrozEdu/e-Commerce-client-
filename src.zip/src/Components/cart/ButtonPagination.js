import React, { useState } from "react";
import { useDispatch, useSelector } from "react-redux";

import { removeFromCart } from "../../Redux/Actions/CartAction";

export default function ButtonPagination({
  item,
  setItemsValue,
  itemsValue,
  index,
  onQuantityIncrement,
  onQuantityDecrement,
}) {
  let [quantity, setQuantity] = useState(item.quantity);
  let dispatch = useDispatch();

  let inc = () => {
    setQuantity(quantity + 1);
    onQuantityIncrement(item._id, quantity + 1);
  };
  let dec = () => {
    if (quantity <= 1) return;
    setQuantity(quantity - 1);
    onQuantityDecrement(item._id, quantity - 1);
  };
  const itemRemove = (_id) => {
    dispatch(removeFromCart(_id));
  };

  return (
    <>
      <div className="cart-pagination d-flex justify-content-start col-12 my-2">
        <div className="mt-1 ">
          <span
            className="mx-2 ms-5 text-dark  text-center small remove-item "
            onClick={() => itemRemove(item._id)}
          >
            Remove
          </span>
        </div>
      </div>
    </>
  );
}
