export const bannerData = [
  {
    id: 1,
    url: "https://rukminim1.flixcart.com/fk-p-flap/1688/280/image/23053b9a9528971b.jpg?q=50",
  },
  {
    id: 2,
    url: "https://rukminim1.flixcart.com/fk-p-flap/1688/280/image/c84d390fd90c7887.jpg?q=50",
  },
  {
    id: 3,
    url: "https://rukminim1.flixcart.com/fk-p-flap/1688/280/image/7bbe3621cb8c7dd5.jpg?q=50",
  },
];
