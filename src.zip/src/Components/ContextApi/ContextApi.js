import { useState, createContext } from "react";
import React from "react";

export const DataContext = createContext(null);

const ContextApi = ({ children }) => {
  const [account, setAccount] = useState("");
  let state = { account, setAccount };
  return <DataContext.Provider value={state}> {children}</DataContext.Provider>;
};

export default ContextApi;
